from django.urls import path
from . import views

urlpatterns = [
    path('', views.HomePage),
    path('shop/', views.shop),
    path('ticket/', views.ticket),
   
]