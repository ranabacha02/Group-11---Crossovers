from django.shortcuts import render
from django.contrib import admin
from django.http import HttpResponse


# Create your views here.
def HomePage(request):
    return HttpResponse('HomePage')

def shop(request):
    return HttpResponse('shop')

def ticket(request):
    return HttpResponse('ticket')



