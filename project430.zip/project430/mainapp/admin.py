from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User
from .models import *


# Register your models here.

admin.site.register(Fan)
admin.site.register(Product)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(ShippingAddress)
admin.site.register(Event)
admin.site.register(History)
admin.site.register(Values)
admin.site.register(News)
admin.site.register(FirstTeamBasket)
admin.site.register(FirstTeamFoot)
admin.site.register(Basic)
admin.site.register(Plus)
admin.site.register(Pro)
