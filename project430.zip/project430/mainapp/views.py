from django.http import JsonResponse
from django.contrib.auth import authenticate, login, logout, get_user_model
from mainapp.decorators import unauthenticated_user
from django.contrib.auth.forms import AuthenticationForm, UsernameField 
from .models import *
import json
import datetime 
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.models import User, Group
from django.contrib.auth import authenticate, login, logout 
from django.core.exceptions import PermissionDenied
from .forms import TicketForm, ItemForm, BasicForm, ProForm, PlusForm
from .forms import EventForm
from .forms import CreateUserForm, FanForm, FirstTeamBasketForm, FanForm1, FirstTeamFootForm, NewsForm, ValuesForm, HistoryForm

from .decorators import unauthenticated_user
# Create your views here.


#marina
def home(request):
    history= History.objects.all()
    values= Values.objects.all()
    news = News.objects.all()
    context={'history': history, 'values': values, 'news': news}
    return render(request, 'homepage/home.html', context)


@unauthenticated_user
def registerPage(request):
    
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            email= form.cleaned_data.get('email')
            Fan.objects.create(user= user, name=username,email=email)

            messages.success(request, 'Account was created for ' + username)
            return redirect('login')
        
    context = {'form':form}
    return render(request, 'homepage/register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password =request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            if request.user.is_staff:
                return redirect('adminhome')
            return redirect('user-profile')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'homepage/login.html', context)


def logoutUser(request):
    if request.user.is_authenticated:
        logout(request)
        return redirect('home')
    else:
        return redirect('login')
    


def userProfile(request):
    if request.user.is_authenticated:
        if(request.user.is_staff):
            raise PermissionDenied()
        fans = Fan.objects.all()
        for fan in fans:
            if request.user == fan.user:
                context ={'fan':fan}
                return render(request, "users/profile.html", context)
        
        return render(request, "homepage/home.html")
    else:
        return redirect('login')


def mySchedule(request):
    if request.user.is_authenticated:
        if(request.user.is_staff):
                raise PermissionDenied()
        fans = Fan.objects.all()
        for fan in fans:
            if request.user == fan.user :
                me = request.user.fan
                events=Event.objects.filter(attendees=me)
                
                #for adding the tickets in my schedule
                #products = Product.objects.all()
                #tickets= products.filter(category="Ticket")
                #orders=OrderItem.objects.filter(product=tickets)

                context={'events':events}

                return render(request,  "users/myschedule.html", context)
            
        return render(request, "homepage/home.html")
    else:
        return redirect('login')

def account_settings(request, pk):
    if request.user.is_authenticated:
        if(request.user.is_staff):
                raise PermissionDenied()
        fan= request.user.fan
        form= FanForm1(instance=fan)
        
        if request.method =="POST":
            #print("printing POST:", request.POST)
            form= FanForm1(request.POST, request.FILES, instance=fan)
            if form.is_valid():
                form.save()
                return redirect('user-profile')
        context ={'form':form, 'fan':fan}
        return render(request, "users/account_settings.html",context)
    else:
        return redirect('login')


def plans(request):
    if request.user.is_authenticated:
        if(request.user.is_staff):
            raise PermissionDenied()
        basics=Basic.objects.all()
        pros=Pro.objects.all()
        pluses=Plus.objects.all()
        context ={'basics':basics, 'pros':pros, 'pluses':pluses}
        return render(request, 'homepage/plans.html',context)
    else:
        return redirect('login')


def RegisterTraining(request,plan):
    if request.user.is_authenticated:
        if(request.user.is_staff):
            raise PermissionDenied()
        fan=request.user.fan
        fan.plan=plan
        fan.category='Trainee'
        fan.save()
        return redirect('home')
    else:
        return redirect('login')


def ticketsinfo(request,pk):
    if request.user.is_authenticated:
        user = request.user
        tickets= Product.objects.get(id=pk)
        context={'tickets': tickets}
        return render(request, 'store/ticketsinfo.html', context)
    else:
        return redirect ('login')

def Attend(request,pk):
    if request.user.is_authenticated:
        if(request.user.is_staff):
            raise PermissionDenied()
        fan = request.user.fan
        event= Event.objects.get(id=pk)
        event.attendees.add(fan)
        event.save()
        return redirect('my-schedule')
    else:
        return redirect ('login')

def storeinfo(request,pk):
    if request.user.is_authenticated:
        user = request.user
        products= Product.objects.get(id=pk)
        context={'products': products}
        return render(request, 'store/storeinfo.html', context)
    else:
        return redirect ('login')

def Football(request):
    firstteamfoot= FirstTeamFoot.objects.all()
    context={'firstteamfoot': firstteamfoot}
    return render(request, 'football/FootballFirstTeam.html',context)
def Basketball(request):
    firstteambasket= FirstTeamBasket.objects.all()
    context={'firstteambasket': firstteambasket}
    return render(request, 'football/BasketballFirstTeam.html', context)
def BasketballFirstTeam(request):
    firstteambasket= FirstTeamBasket.objects.all()
    context={'firstteambasket': firstteambasket}
    return render(request, 'basketball/BasketballFirstTeam.html',context)
def FootballFirstTeam(request):
    firstteamfoot= FirstTeamFoot.objects.all()
    context={'firstteamfoot': firstteamfoot}
    return render(request, 'football/FootballFirstTeam.html',context)

def BasketballSchedule(request):
    event_list= Event.objects.all()
    basket_event_list=event_list.filter(category="Basketball")
    context={'basket_event_list': basket_event_list}
    return render(request, 'basketball/BasketballSchedule.html',context)

def FootballSchedule(request):
    event_list= Event.objects.all()
    foot_event_list=event_list.filter(category="Football")
    context={'foot_event_list': foot_event_list}
    return render(request, 'football/FootballSchedule.html',context)

def store(request):
    if request.user.is_authenticated:
        user = request.user
        order, created = Order.objects.get_or_create(user=user, complete=False)
        items= order.orderitem_set.all()
        cartItems = order.get_cart_items
    #else:
    #    items=[]
    #   order = {'get_cart_total': 0, 'get_cart_items':0, 'shipping':False}
    #    cartItems = order [ 'get_cart_items']
        products= Product.objects.all()
        shopItems= products.filter(category="ShopItem")

        context={'shopItems': shopItems, 'cartItems': cartItems}
        return render(request, 'store/store.html', context)
    else:
        return redirect('login')

def tickets(request):
    if request.user.is_authenticated:
        user = request.user
        order, created = Order.objects.get_or_create(user=user, complete=False)
        items= order.orderitem_set.all()
        cartItems = order.get_cart_items

        #items=[]
        #order = {'get_cart_total': 0, 'get_cart_items':0, 'shipping':False}
        #cartItems = order [ 'get_cart_items']
    
        products= Product.objects.all()
        tickets= products.filter(category="Ticket")
        context={'tickets': tickets, 'cartItems': cartItems}
        return render(request, 'store/tickets.html', context)
    else:
        return redirect ('login')

def cart(request):

    if request.user.is_authenticated:
        user = request.user
        order, created = Order.objects.get_or_create(user=user, complete=False)
        items= order.orderitem_set.all()
        cartItems = order.get_cart_items
        #items=[]
       #order = {'get_cart_total': 0, 'get_cart_items':0, 'shipping':False}
        #cartItems = order [ 'get_cart_items']
        context = { 'items': items, 'order': order, 'cartItems': cartItems}
        return render(request, 'store/cart.html',context)
    else:
        return redirect ('login')

def checkout(request):
    if request.user.is_authenticated:
        user = request.user
        order, created = Order.objects.get_or_create(user=user, complete=False)
        items= order.orderitem_set.all()
        cartItems = order.get_cart_items
        #items=[]
        #order = {'get_cart_total': 0, 'get_cart_items':0, 'shipping':False}
        #cartItems = order.get_cart_items

        context = { 'items': items, 'order': order, 'cartItems': cartItems}
        return render(request, 'store/checkout.html', context)
    else:
        return redirect ('login')

def updateItem(request):
    data= json.loads(request.body)
    productId = data['productId']
    action = data['action']
    print('productId', productId)
    print('Action', action)

    user = request.user
    product = Product.objects.get(id= productId)
    order, created = Order.objects.get_or_create(user=user, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(order=order, product=product)

    if action == 'add':
        if (orderItem.product.quantity>orderItem.quantity):
            orderItem.quantity = (orderItem.quantity + 1)
        else:
            print(orderItem.product.quantity)
            messages.error(request,"Not enough quantity")
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()

    if orderItem.quantity <= 0:
        orderItem.delete()
    

    return JsonResponse('Item was added', safe=False)

#from django.views.decorators.csrf import csrf_exempt
#@csrf_exempt

def processOrder(request):
    transaction_id = datetime.datetime.now().timestamp()
    data = json.loads(request.body)

    if request.user.is_authenticated:
        user = request.user
        order, created = Order.objects.get_or_create(user=user, complete=False)
        total = float(data['form']['total'])
        order.transaction_id = transaction_id
        orderitems = order.orderitem_set.all()

        products_in_order = []
        quantity_of_products = []
        for orderitem in orderitems:
            products_in_order.append(orderitem.product)
            quantity_of_products.append(orderitem.quantity)
        #needed for security

        if total == order.get_cart_total:
            order.complete = True
        order.save()

        if order.shipping == True:
            ShippingAddress.objects.create(
            #customer=user,
            order=order,
            address=data['shipping']['address'],
            city=data['shipping']['city'],
            state=data['shipping']['state'],
            zipcode=data['shipping']['zipcode'],
            )
 
        for i in range(len(products_in_order)):
            print('productId', products_in_order[i].name)
            products_in_order[i].quantity-=quantity_of_products[i]
            products_in_order[i].save()
        
    else:
        return redirect ('login')
    
    
    return JsonResponse('Payment submitted..', safe=False)


def news(request):
    page ='news'
    news= News.objects.all()
    context={'news': news}
    return render(request, 'homepage/news_home.html', context)

def updateBasic(request,pk):
    basic= Basic.objects.get(id=pk)
    form= BasicForm(instance=basic)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= BasicForm(request.POST, instance=basic)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/basic_form.html',context)

def updatePro(request,pk):
    pro= Pro.objects.get(id=pk)
    form= ProForm(instance=pro)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= ProForm(request.POST, instance=pro)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/pro_form.html',context)

def updatePlus(request,pk):
    plus= Plus.objects.get(id=pk)
    form= PlusForm(instance=plus)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= PlusForm(request.POST, instance=plus)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/plus_form.html',context)


#Rana

def AllOrders(request):
    if (request.user.is_authenticated):
        if(not request.user.is_staff):
            raise PermissionDenied()
        totalorders=Order.objects.all()
        context={'totalorders':totalorders}
        return render(request, "adminpages/all_orders.html", context)
    else:
        return redirect('login')

def adminhome(request):
    if (request.user.is_authenticated):
        if(not request.user.is_staff):
            raise PermissionDenied()
        orders=Order.objects.all()[:5]
        fans = Fan.objects.all()
        products = Product.objects.all()
        total_fans=fans.count()
        
        tickets= products.filter(category="Ticket")
        shopitems=products.filter(category="ShopItem")
        events = Event.objects.all()

        firstteambasket = FirstTeamBasket.objects.all()
        firstteamfoot = FirstTeamFoot.objects.all()

        totalorders=Order.objects.all()
        total_orders = totalorders.count()

        news=News.objects.all()

        values=Values.objects.all()

        history=History.objects.all()

        basic=Basic.objects.all()
        pro=Pro.objects.all()
        plus=Plus.objects.all()

        context={'history': history,'basic': basic,'pro': pro,'plus': plus,'values': values, 'news': news, 'orders': orders, 'fans': fans, 'total_orders': total_orders,  'products': products, 'shopitems':shopitems, 'tickets': tickets, 'events': events, 'total_fans': total_fans, 'firstteambasket': firstteambasket, 'firstteamfoot': firstteamfoot}
        return render(request, "adminpages/dashboard.html", context)
    else:
        return redirect('login')

def createTicket(request):
    form =TicketForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= TicketForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/product_form.html",context)

def updateTicket(request,pk):
    product= Product.objects.get(id=pk)
    form= TicketForm(instance=product)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= TicketForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/product_form.html',context)


def deleteTicket(request,pk):
    product= Product.objects.get(id=pk)
    if request.method=='POST':
        product.delete()
        return(redirect('adminhome'))
    context ={'item':product}
    return render(request, "adminpages/delete_product.html", context)


def createItem(request):
    form =ItemForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= ItemForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/product_form.html",context)

def updateItem1(request,pk):
    product= Product.objects.get(id=pk)
    form= ItemForm(instance=product)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= ItemForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/product_form.html',context)


def deleteItem(request,pk):
    product= Product.objects.get(id=pk)
    if request.method=='POST':
        product.delete()
        return(redirect('adminhome'))
    context ={'item':product}
    return render(request, "adminpages/delete_product.html", context)


def createFan(request):
    form =FanForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= FanForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/fan_form.html",context)

def updateFan(request,pk):
    fan= Fan.objects.get(id=pk)
    form= FanForm(instance=fan)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= FanForm(request.POST, request.FILES, instance=fan)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/fan_form.html',context)


def deleteFan(request,pk):
    fan= Fan.objects.get(id=pk)
    if request.method=='POST':
        fan.delete()
        return(redirect('adminhome'))
    context ={'item':fan}
    return render(request, "adminpages/delete_fan.html", context)

def createEvent(request):
    form =EventForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= EventForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/events_form.html",context)

def updateEvent(request,pk):
    event= Event.objects.get(id=pk)
    form= EventForm(instance=event)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= EventForm(request.POST, instance=event)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/events_form.html',context)


def deleteEvent(request,pk):
    event= Event.objects.get(id=pk)
    if request.method=='POST':
        event.delete()
        return(redirect('adminhome'))
    context ={'item':event}
    return render(request, "adminpages/delete_event.html", context)

def products(request):
    products =Product.objects.all()
    return render(request,'adminpages/products.html',{'products':products})



def createFirstTeamBasket(request):
    form =FirstTeamBasketForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= FirstTeamBasketForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/FirstTeamBasket_form.html",context)

def updateFirstTeamBasket(request,pk):
    firstteambasket= FirstTeamBasket.objects.get(id=pk)
    form= FirstTeamBasketForm(instance=firstteambasket)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= FirstTeamBasketForm(request.POST, request.FILES, instance=firstteambasket)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/FirstTeamBasket_form.html',context)


def deleteFirstTeamBasket(request,pk):
    firstteambasket= FirstTeamBasket.objects.get(id=pk)
    if request.method=='POST':
        firstteambasket.delete()
        return(redirect('adminhome'))
    context ={'item':firstteambasket}
    return render(request, "adminpages/delete_FirstTeamBasket.html", context)


def createFirstTeamFoot(request):
    form =FirstTeamFootForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= FirstTeamFootForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/FirstTeamFoot_form.html",context)

def updateFirstTeamFoot(request,pk):
    firstteamfoot= FirstTeamFoot.objects.get(id=pk)
    form= FirstTeamFootForm(instance=firstteamfoot)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= FirstTeamFootForm(request.POST, request.FILES, instance=firstteamfoot)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/FirstTeamFoot_form.html',context)


def deleteFirstTeamFoot(request,pk):
    firstteamfoot= FirstTeamFoot.objects.get(id=pk)
    if request.method=='POST':
        firstteamfoot.delete()
        return(redirect('adminhome'))
    context ={'item':firstteamfoot}
    return render(request, "adminpages/delete_FirstTeamFoot.html", context)


def createHistory(request):
    form =HistoryForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= HistoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/History_form.html",context)

def updateHistory(request,pk):
    history= History.objects.get(id=pk)
    form= HistoryForm(instance=history)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= HistoryForm(request.POST, instance=history)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/History_form.html',context)




def createValues(request):
    form =ValuesForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= ValuesForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/Values_form.html",context)

def updateValues(request,pk):
    values= Values.objects.get(id=pk)
    form= ValuesForm(instance=news)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= ValuesForm(request.POST, instance=values)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/Values_form.html',context)





def createNews(request):
    form =NewsForm()
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= NewsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('adminhome')

    context={'form': form}
    return render(request, "adminpages/News_form.html",context)

def updateNews(request,pk):
    news= News.objects.get(id=pk)
    form= NewsForm(instance=news)
    
    if request.method =="POST":
        #print("printing POST:", request.POST)
        form= NewsForm(request.POST, instance=news)
        if form.is_valid():
            form.save()
            return redirect('adminhome')
    context ={'form':form}
    return render(request, 'adminpages/News_form.html',context)



# ADDED BY NADER 21/4/2022
def all_events_basket(request):
	event_list = Event.objects.all().filter(category='Basketball').order_by('-event_date')
	return render(request, 'basketball/BasketballSchedule.html', 
		{'event_list': event_list})

# ADDED BY NADER 21/4/2022
def all_events_foot(request):
	event_list = Event.objects.all().filter(category='Football').order_by('-event_date')
	return render(request, 'football/FootballSchedule.html', 
		{'event_list': event_list})


