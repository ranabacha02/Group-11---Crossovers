from django.urls import path
from . import views
from django.http import HttpResponse
from django.conf.urls import url # COMMENTED BY NADER 
from django.urls import re_path # ADDED BY NADER 21/4/2022 BECAUSE THE PREVIOUS LINE DOES NOT WORK ON HIS LAPTOP
#from django.contrib.auth.models import User
#from django.contrib.auth.forms import UserCreationForm 


urlpatterns = [
    path('', views.home, name="home"),
    path('register/', views.registerPage, name="register"),
	path('login/', views.loginPage, name="login"),  
	path('logout/', views.logoutUser, name="logout"),
    path('plans/', views.plans, name="plans"),  
    path('userprofile/',views.userProfile, name="user-profile"),
    path('myschedule/',views.mySchedule, name="my-schedule"),
    path('account_settings/<str:pk>/', views.account_settings, name="account_settings"),
    path('registertraining/<str:plan>/',views.RegisterTraining, name="register-training"),

    path('attend/<str:pk>/',views.Attend, name="attend"),

    path('ticketsinfo/<str:pk>/', views.ticketsinfo, name="ticketsinfo"),
    path('storeinfo/<str:pk>/', views.storeinfo, name="storeinfo"),

   
    path('store/', views.store, name="store"),
    path('tickets/', views.tickets, name="tickets"),
	path('cart/', views.cart, name="cart"),
	path('checkout/', views.checkout, name="checkout"),
	path('update_item/', views.updateItem, name = "update_item"),
	path('process_order/', views.processOrder, name = "process_order"),
    path('news/', views.news, name="news"),

    path('all_orders/', views.AllOrders, name="all_orders"),

    path('football/', views.Football, name="Football"),
    path('basketball/', views.Basketball, name="Basketball"),
    path('FootballFirstTeam/', views.FootballFirstTeam, name="FootballFirstTeam"),
    path('FootballSchedule/', views.FootballSchedule, name="FootballSchedule"),
    path('BasketballFirstTeam/', views.BasketballFirstTeam, name="BasketballFirstTeam"),
    path('BasketballSchedule/', views.BasketballSchedule, name="BasketballSchedule"),

    path('create_item/', views.createItem, name="create_item"),
    path('update_item/<str:pk>/', views.updateItem1, name="update_item"),
    path('delete_item/<str:pk>/', views.deleteItem, name="delete_item"),
    path('create_ticket/', views.createTicket, name="create_ticket"),
    path('update_ticket/<str:pk>/', views.updateTicket, name="update_ticket"),
    path('delete_ticket/<str:pk>/', views.deleteTicket, name="delete_ticket"),

    path('create_fan/', views.createFan, name="create_fan"),
    path('update_fan/<str:pk>/', views.updateFan, name="update_fan"),
    path('delete_fan/<str:pk>/', views.deleteFan, name="delete_fan"),

    path('create_event/', views.createEvent, name="create_event"),
    path('update_event/<str:pk>/', views.updateEvent, name="update_event"),
    path('delete_event/<str:pk>/', views.deleteEvent, name="delete_event"),

    path('create_FirstTeamBasket/', views.createFirstTeamBasket, name="create_FirstTeamBasket"),
    path('update_FirstTeamBasket/<str:pk>/', views.updateFirstTeamBasket, name="update_FirstTeamBasket"),
    path('delete_FirstTeamBasket/<str:pk>/', views.deleteFirstTeamBasket, name="delete_FirstTeamBasket"),

    path('create_FirstTeamFoot/', views.createFirstTeamFoot, name="create_FirstTeamFoot"),
    path('update_FirstTeamFoot/<str:pk>/', views.updateFirstTeamFoot, name="update_FirstTeamFoot"),
    path('delete_FirstTeamFoot/<str:pk>/', views.deleteFirstTeamFoot, name="delete_FirstTeamFoot"),

    path('create_News/', views.createNews, name="create_News"),
    path('update_News/<str:pk>/', views.updateNews, name="update_News"),

    path('create_Values/', views.createValues, name="create_Values"),
    path('update_Values/<str:pk>/', views.updateValues, name="update_Values"),

    path('create_History/', views.createHistory, name="create_History"),
    path('update_History/<str:pk>/', views.updateHistory, name="update_History"),

    path('update_basic/<str:pk>/', views.updateBasic, name="update_Basic"),
    path('update_plus/<str:pk>/', views.updatePlus, name="update_Plus"),
    path('update_pro/<str:pk>/', views.updatePro, name="update_Pro"),

    path('adminhome', views.adminhome, name="adminhome"),
    path('products/', views.products, name="products"),
    #path('user/<str:pk_test>/', request.user, name="user"),


]