from django.db import models
from django.contrib.auth.models import User  #import User model (table)
from django.db.models.deletion import CASCADE
from django.core.validators import MaxValueValidator, MinValueValidator
from datetime import date, datetime
from django.utils import timezone



# Create your models (database tables) here.

#we create python classes who represent tables
#every attribute in that class represent a column in the table
#every instance is a row
class Fan(models.Model):
	CATEGORY = (('Trainee', 'Trainee'), ('Coach','Coach'), ('Fan','Fan'))
	user = models.OneToOneField(User, related_name="fan", on_delete=models.CASCADE, blank= True, null=True)
	name = models.CharField(max_length=200, null=True)
	phone = models.CharField(max_length=200, null=True)
	email = models.EmailField(max_length=254, null=True)
	profilepic = models.ImageField(default="default.jpeg", null=True, blank=True)
	dob = models.DateField(null=True, help_text="in yyyy-mm-dd format",validators=[MaxValueValidator(limit_value=date.today)])
	category = models.CharField(max_length=200, blank=True, null=True, choices=CATEGORY, default= 'Fan')
	plan = models.CharField(max_length=200, blank=True, null=True, default= 'Basic')

	def __str__(self):
		return self.name


	@property
	def get_orders(self):
		orderitems = self.order_set.all()
		return orderitems

	@property
	def set_trainee(self):
		self.category = 'Trainee'
		self.save()
		return

	@property
	def imageURL(self):
		try:
			url = self.image.url
		except:
			url = ''
		return url


class History(models.Model):
    description = models.TextField(blank=True)
  
class Values(models.Model):
	description = models.TextField(blank=True)
  
class News(models.Model):
	title= models.CharField(max_length=200, default = "BREAKING NEWS")
	description = models.TextField(blank=True)
	image= models.ImageField(default="news1.jpeg", blank=True)

class FirstTeamBasket(models.Model):
	CATEGORY = (('Guard', 'Guard'), ('Forward','Forward'), ('Center','Center'),('Coaching Staff','Coaching Staff'))
	name = models.CharField(max_length=200, null=True)
	number = models.IntegerField(null=True, validators=[MinValueValidator(limit_value=0)])
	Appearances = models.IntegerField(null=True,validators=[MinValueValidator(limit_value=0)])
	profilepic = models.ImageField(default = "marc.jpeg",blank=True)
	category = models.CharField(max_length=200, blank=True, null=True, choices=CATEGORY)

	def __str__(self):
		return self.name

class FirstTeamFoot(models.Model):
	CATEGORY = (('Goalkeeper', 'Goalkeeper'), ('Defender','Defender'), ('Midfielder','Midfielder'), ('Forward','Forward'), ('Coaching Staff','Coaching Staff'))
	name = models.CharField(max_length=200, null=True)
	number = models.IntegerField(null=True, validators=[MinValueValidator(limit_value=0)])
	Appearances = models.IntegerField(null=True, validators=[MinValueValidator(limit_value=0)])
	profilepic = models.ImageField(default = "marc.jpeg",blank=True)
	category = models.CharField(max_length=200, blank=True, null=True, choices=CATEGORY)

	def __str__(self):
		return self.name

class Basic(models.Model):
	feature1 = models.CharField(max_length=200, blank=True, null=True)
	feature2 = models.CharField(max_length=200, blank=True, null=True)
	feature3 = models.CharField(max_length=200, blank=True, null=True)
	feature4 = models.CharField(max_length=200, blank=True, null=True)
	feature5 = models.CharField(max_length=200, blank=True, null=True)
	price = models.FloatField(validators=[MinValueValidator(limit_value=0)])
	

class Plus(models.Model):
	feature1 = models.CharField(max_length=200, blank=True, null=True)
	feature2 = models.CharField(max_length=200, blank=True, null=True)
	feature3 = models.CharField(max_length=200, blank=True, null=True)
	feature4 = models.CharField(max_length=200, blank=True, null=True)
	feature5 = models.CharField(max_length=200, blank=True, null=True)
	price = models.FloatField(validators=[MinValueValidator(limit_value=0)])
	

class Pro(models.Model):
	feature1 = models.CharField(max_length=200, blank=True, null=True)
	feature2 = models.CharField(max_length=200, blank=True, null=True)
	feature3 = models.CharField(max_length=200, blank=True, null=True)
	feature4 = models.CharField(max_length=200, blank=True, null=True)
	feature5 = models.CharField(max_length=200, blank=True, null=True)
	price = models.FloatField(validators=[MinValueValidator(limit_value=0)])
	

class Product(models.Model):
	CATEGORY = (('Ticket', 'Ticket'), ('ShopItem','ShopItem'))
	SEATCategory = (('Front', 'Front'), ('Back','Back'))
	name = models.CharField(max_length=200)
	price = models.FloatField(validators=[MinValueValidator(limit_value=0)])
	digital = models.BooleanField(default=False,null=True, blank=True)
	image = models.ImageField(default= "placeholder.png", null=True, blank=True)
	category = models.CharField(max_length=200,null=True, choices=CATEGORY)
	quantity = models.IntegerField(default=0, null=True, validators=[MinValueValidator(limit_value=0)])
	date=models.DateTimeField('Date',null=True,help_text="in yyyy-mm-dd HH:MM:SS format",blank=True,validators=[MinValueValidator(limit_value=timezone.now())]) #will be removed from the item form
	seat=models.CharField(max_length=200,null=True,blank=True, choices=SEATCategory) #will be removed from the item form
	description = models.TextField(blank=True) 
	location=models.TextField(blank=True) #will be removed from the item form
	def _str_(self):
		return self.name

	@property
	def imageURL(self):
		try:
			url = self.image.url
		except:
			url = ''
		return url
	
class Order(models.Model):
	user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
	date_ordered = models.DateTimeField(auto_now_add=True)
	complete = models.BooleanField(default=False)
	transaction_id = models.CharField(max_length=100, null=True)

	def __str__(self):
		return str(self.id)

	@property
	def shipping(self):
		shipping = False
		orderitems = self.orderitem_set.all()
		for i in orderitems:
			if i.product.digital == False:
				shipping = True
		return shipping
		
	@property
	def get_cart_total(self):
		orderitems = self.orderitem_set.all()
		total = sum([item.get_total for item in orderitems])
		return total 

	@property
	def get_cart_items(self):
		orderitems = self.orderitem_set.all()
		total = sum([item.quantity for item in orderitems])
		return total 


class OrderItem(models.Model):
	product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
	order = models.ForeignKey(Order, on_delete=models.SET_NULL, null=True)
	quantity = models.IntegerField(default=0, null=True, blank=True)
	date_added = models.DateTimeField(auto_now_add=True)

	@property
	def get_total(self):
		total = self.product.price * self.quantity
		return total

class ShippingAddress(models.Model):
	user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
	order = models.ForeignKey(Order, on_delete=models.SET_NULL, null=True)
	address = models.CharField(max_length=200, null=False)
	city = models.CharField(max_length=200, null=False)
	state = models.CharField(max_length=200, null=False)
	zipcode = models.CharField(max_length=200, null=False)
	date_added = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return self.address



class Event(models.Model):
	CATEGORY = (('Basketball', 'Basketball'), ('Football','Football')) # ADDED BY NADER 21/4/2022
	name = models.CharField('Event Name', max_length=120)
	event_date = models.DateTimeField('Event Date',validators=[MinValueValidator(limit_value=timezone.now())])
	description = models.TextField(blank=True)
	attendees = models.ManyToManyField(Fan, null=True)
	approved = models.BooleanField('Aprroved', default=False)
	manager=models.ManyToManyField(Fan, related_name= 'Coach',null=True)
	category = models.CharField(max_length=200, blank=True, null=True, choices=CATEGORY) # ADDED BY NADER 21/4/2022
	
	def __str__(self):
		return self.name
	
# ADDED BY NADER 21/4/2022
	@property
	def Days_till(self):
		today = date.today()
		days_till = self.event_date.date() - today
		days_till_stripped = str(days_till).split(",", 1)[0]
		return days_till_stripped

# ADDED BY NADER 21/4/2022
	@property
	def Is_Past(self):
		today = date.today()
		return (self.event_date.date() < today)
		#	thing = "Past"
		#else:
		#	thing = "Future"
		#return thing


