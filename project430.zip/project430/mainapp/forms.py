from django.forms import ModelForm      #instead of writing forms manually
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from .models import *

class CreateUserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']

class FanForm(ModelForm):
    class Meta:
        model = Fan
        fields ='__all__'
        exclude = ['user']

class FanForm1(ModelForm):
    class Meta:
        model = Fan
        fields ='__all__'
        exclude = ['user', 'category', 'plan']

class OrderForm(ModelForm):
    class Meta:
        model = Order
        fields = '__all__'


class UserForm(ModelForm):
    class Meta:
        model = User
        fields = '__all__'

class ItemForm(ModelForm):
    class Meta:
        model = Product
        fields = '__all__'
        exclude = ['category', 'date', 'seat', 'location']

class TicketForm(ModelForm):
    class Meta:
        model = Product
        fields = '__all__'

class BasicForm(ModelForm):
    class Meta:
        model = Basic
        fields = '__all__'

class ProForm(ModelForm):
    class Meta:
        model = Pro
        fields = '__all__'

class PlusForm(ModelForm):
    class Meta:
        model = Plus
        fields = '__all__'

class EventForm(ModelForm):
    class Meta:
        model = Event
        fields = ('name', 'event_date', 'category','attendees','manager', 'description')
        labels = {
            'name': '',
            'event_date': 'YYYY-MM-DD HH:MM:SS',
            'category': 'Category',
            # 'venue': 'Venue',
            'attendees': 'Attendees',
            'manager': 'Manager',
            'description': '',          
        }
        widgets = {
            'name': forms.TextInput(attrs={'class':'form-control', 'placeholder':'Event Name'}),
            'event_date': forms.TextInput(attrs={'class':'form-control', 'placeholder':'Event Date'}),
            'category': forms.Select(attrs={'class':'form-control', 'placeholder':'Event Category'}),
            # 'venue': forms.Select(attrs={'class':'form-select', 'placeholder':'Venue'}),
            'attendees': forms.SelectMultiple(attrs={'class':'form-control', 'placeholder':'Attendees'}),
            'manager': forms.SelectMultiple(attrs={'class':'form-control', 'placeholder':'Manager'}),
            'description': forms.Textarea(attrs={'class':'form-control', 'placeholder':'Description'}),
        }

class FirstTeamBasketForm(ModelForm):
    class Meta:
        model = FirstTeamBasket
        fields = '__all__'

class FirstTeamFootForm(ModelForm):
    class Meta:
        model = FirstTeamFoot
        fields = '__all__'

class NewsForm(ModelForm):
    class Meta:
        model = News
        fields = '__all__'

class ValuesForm(ModelForm):
    class Meta:
        model = Values
        fields = '__all__'

class HistoryForm(ModelForm):
    class Meta:
        model = History
        fields = '__all__'



